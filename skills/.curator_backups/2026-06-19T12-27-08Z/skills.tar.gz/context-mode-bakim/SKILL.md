---
name: context-mode-bakim
description: "Context-mode MCP server bakim. Ikili kayit cakismasi cozumu, FTS5/SQLite onarimi, versiyon guncelleme, gateway restart."
version: 1.0.0
metadata:
  hermes:
    tags: [context-mode, mcp, server, troubleshooting, bakim]
    category: devops
---

# Context-mode MCP Server Bakimi

Context-mode MCP server'i Hermes'in FTS5/session arama ve sandbox execute altyapisini saglar.

## Belirtiler

- Tool listesinde `mcp_context_mode_*` toollari yok
- `ctx_doctor`'da `FTS5 / SQLite: FAIL` veya versiyon uyarisi
- Context-mode process `ps aux`'da gorunmuyor
- Gateway log'da `Failed to parse JSONRPC message`

## Ikili Kayit Cakismasi (En Sik Karsilasilan)

Context-mode hem config.yaml'de MCP server olarak, hem de opencode.json'da plugin+MCP olarak kayitliysa toollari bilerek bosaltir.

**Belirti:** `ctx_* tools/list intentionally empty`

**Cozum:** opencode.json'dan context-mode referanslarini kaldir.

## FTS5/SQLite Modul Eksik

`ctx_doctor` → `FTS5 / SQLite: FAIL`

**Cozum:** `ALL_PROXY="" npm update -g context-mode`

## Versiyon Guncelleme

```bash
npm update -g context-mode
context-mode --version
# v1.0.162+ olmali
```

## Gateway Restart

```bash
systemctl --user restart hermes-gateway
```

Eger `deactivating` durumunda takilirsa:
- Main PID'i bul ve `kill -9` ile oldur, sonra start et.

## Dogrulama

- `ps aux | grep context-mode` — process calisiyor mu?
- `mcp_context_mode_ctx_doctor` — tum kontroller PASS mi?
