---
name: pollinations-image
description: "Pollinations görsel üretim modelleri — tam liste keşfi, model kategorileri, NSFW filtre davranışları"
version: 1.0.0
metadata:
  hermes:
    tags: [pollinations, image-generation, models, api]
    category: media
---

# Pollinations Görsel Modelleri

## Model Keşfi — Play Sayfasına Güvenme!

**Pitfall:** `pollinations.ai/play` sayfası sadece bir alt küme gösterir (~20 model). Tam listeyi ALMAZ.

**Doğru yöntem:** API endpoint'ini sorgula:

```bash
curl https://gen.pollinations.ai/v1/models | jq '.data[].id'
```

veya Python ile:

```python
import requests
resp = requests.get("https://gen.pollinations.ai/v1/models")
models = [m["id"] for m in resp.json()["data"]]
```

Toplam ~94 model döner (Mayıs 2026 itibarıyla).

## Görsel Modeller (Tam Liste)

| Slug | Sağlayıcı | Tip |
|------|-----------|-----|
| `flux` | Black Forest Labs | Açık kaynak |
| `kontext` | Black Forest Labs | FLUX.1 Kontext (referanslı) |
| `zimage` | — | Z-Image Turbo |
| `klein` | Black Forest Labs | FLUX.2 Klein 4B |
| `nanobanana` | Google | NanoBanana |
| `nanobanana-2` | Google | NanoBanana 2 |
| `nanobanana-pro` | Google | NanoBanana Pro |
| `seedream` | ByteDance | Seedream 4.0 |
| `seedream5` | ByteDance | Seedream 5.0 Lite |
| `seedream-pro` | ByteDance | Seedream 4.5 Pro |
| `gptimage` | OpenAI | GPT Image 1 Mini |
| `gptimage-large` | OpenAI | GPT Image 1.5 |
| `gpt-image-2` | OpenAI | GPT Image 2 |
| `wan-image` | Alibaba | Wan 2.7 Image |
| `wan-image-pro` | Alibaba | Wan 2.7 Image Pro |
| `qwen-image` | Alibaba | Qwen Image Plus |
| `grok-imagine` | xAI | Grok Imagine |
| `grok-imagine-pro` | xAI | Grok Imagine Pro |
| `p-image` | Pruna | Pruna p-image |
| `p-image-edit` | Pruna | Pruna p-image-edit |
| `nova-canvas` | Amazon | Nova Canvas |

💎 = Play'de "Pollen puanı" ile işaretli olanlar ücretli olabilir.

## NSFW Filtre Davranışı

Pollinations genel olarak NSFW filtre uygular, ama model bazında farklılık gösterir:

### Daha gevşek filtre (açık kaynaklı modeller)
- `flux`, `kontext`, `zimage`, `klein` — Flux ailesi, açık kaynak, filtre daha az katı
- `wan-image`, `wan-image-pro` — Alibaba açık modelleri

### Daha katı filtre (kapalı API modelleri)
- `gptimage`, `gptimage-large`, `gpt-image-2` — OpenAI kendi güvenlik filtresini uygular
- `grok-imagine`, `grok-imagine-pro` — xAI katı filtre
- `seedream`, `seedream5`, `seedream-pro` — ByteDance kendi filtresi
- `nanobanana`, `nanobanana-2`, `nanobanana-pro` — Google filtre
- `nova-canvas` — Amazon filtre

### Kullanım

Image generation endpoint'i:

```
GET https://gen.pollinations.ai/image/{prompt}?model=flux&width=1024&height=1024&seed=0
```

Header: `Authorization: Bearer YOUR_API_KEY`

## Referans

- API Docs: https://gen.pollinations.ai/docs
- Model listesi: `GET /v1/models` (no auth required)
- Play sayfası (eksik): https://pollinations.ai/play
