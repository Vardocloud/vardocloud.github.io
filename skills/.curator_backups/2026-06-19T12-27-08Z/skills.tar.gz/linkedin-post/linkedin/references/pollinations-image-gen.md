# Pollinations Görsel Üretim — LinkedIn Postları İçin

## Doğru Endpoint

| Endpoint | API Key | Model Param | Sonuç |
|----------|---------|-------------|-------|
| `gen.pollinations.ai/image/{prompt}?model=flux` | Zorunlu | Çalışır | Doğru model |
| `image.pollinations.ai/prompt/{prompt}?model=flux` | Gerekmez | Yoksayılır | Default model |

**Her zaman `gen.pollinations.ai` kullan.** `image.pollinations.ai` model parametresini yoksayar, hep default model döner.

## API Key ile Çalışma (KRİTİK)

Pollinations API key'i özel karakterler içerir (`{`, `}`, `=` vb.). Bu karakterler:
- Bash heredoc/string'de syntax error yapar
- Python f-string'de `{` karakteri değişken işareti olarak yorumlanır
- `write_file` ile dosyaya yazarken linter hatası verir

**Güvenilir yöntem:** Key'i ayrı bir geçici dosyaya yaz, Python script'i o dosyadan okusun. API key'i asla bash değişkeni olarak kullanma, asla Python string literal'ine gömme.

**KESİNLİKLE YAPMA:**
- `export KEY=$(...)` — bash'te syntax error
- Python'da f-string içinde key kullanma — `{` karakteri bozar
- `.env` dosyasını `read_file` ile okumaya çalışma — Hermes güvenlik katmanı engeller

## Kullanılabilir Görsel Modelleri

| Model | Çıktı | Kullanım |
|-------|-------|----------|
| `flux` | 60-67KB | En iyi genel kalite |
| `nanobanana-2` | 46-175KB | Prompt kalitesine çok duyarlı |
| `nanobanana-pro` | 36KB | nanobanana-2'den düşük |

## Prompt Optimizasyonu

Basit prompt (`"calm mind minimalist"`) → 46KB, düşük detay
Detaylı prompt → 175KB, yüksek detay

**İyi prompt şablonu:**
```
A serene abstract illustration for a psychology practice,
two gentle flowing silhouettes in conversation,
soft watercolor texture in [renk paleti],
minimalist geometric elements suggesting [tema],
professional yet warm, clean composition, no text
```

## LinkedIn Görsel Boyutu

Önerilen: 1200×628 (LinkedIn link paylaşım oranı)
Model: `nanobanana-2` — en iyi fiyat/performans
