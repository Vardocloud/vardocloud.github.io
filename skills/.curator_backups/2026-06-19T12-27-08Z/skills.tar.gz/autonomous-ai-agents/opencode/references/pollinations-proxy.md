# Pollinations Proxy for OpenCode

## Why Needed

Pollinations API uses Cloudflare that blocks default Python User-Agent (error 1010). OpenCode's AI SDK sends requests without browser UA — the proxy bridges this gap.

## What It Does

1. **UA Spoofing**: Injects browser User-Agent to bypass Cloudflare
2. **Format Translation**: Converts `/v1/responses` → `/v1/chat/completions` for OpenCode
3. **Fake Endpoints**: Returns mock responses for probe endpoints (`/v1/props`, `/version`, `/api/tags`)
4. **Auth passthrough**: Handles credentials transparently

Location: `~/.hermes/scripts/pollinations-proxy.py`

## OpenCode Config

Provider config in `~/.config/opencode/opencode.json`:
```json
"provider": {
  "pollinations": {
    "npm": "@ai-sdk/openai-compatible",
    "name": "Pollinations",
    "options": { "baseURL": "http://127.0.0.1:19999/v1" },
    "models": {
      "minimax": { "name": "MiniMax 2.7" },
      "glm": { "name": "GLM 4.5" },
      "gpt-5.4-mini": { "name": "GPT 5.4 Mini" },
      "gemma": { "name": "Gemma 3 27B" }
    }
  }
}
```

Set env var before running: `export POLLINATIONS_API_KEY=<placeholder>` (proxy handles actual auth).

## Lifecycle

```bash
# Kill old
fuser -k 19999/tcp

# Start (background)
terminal(command="python3 ~/.hermes/scripts/pollinations-proxy.py 2>/tmp/proxy_debug.log", background=true)

# Health check
terminal(command="curl -s http://127.0.0.1:19999/v1/models")
```

## Pitfalls

- **Logs**: Proxy writes to stderr — redirect with `2>/tmp/proxy_debug.log`
- **Port conflicts**: Always `fuser -k` before restart
- **Model IDs**: Use short IDs (`minimax`, `glm`) not full paths
- **Debug order**: Test `curl` → proxy first, then OpenCode. If curl works but OpenCode doesn't, the issue is in provider config or format translation
- **OpenCode output**: `opencode run` with custom providers may be silent for text responses — verify via SQLite DB (`~/.local/share/opencode/opencode.db`) or TUI mode
