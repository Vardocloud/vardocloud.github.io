# Pollinations + OpenCode Full Integration (31 May 2026)

## Why Pollinations for OpenCode Sub-Agents

Pollinations offers **free/unlimited** models that are ideal for sub-agent roles:
- `minimax` (MiniMax M2.7): SWE-bench 80.2% — best coding quality among free models
- `glm` (GLM-5/4.5): MMLU 91.7% — best analysis/reasoning
- `gpt-5.4-mini`: Best Turkish creative writing (14+ model comparison)
- `gemma` (Gemma 3 27B): Lightweight, has vision capability

## Architecture: Multi-Agent "Ekip" (Team)

```
Primary Agent (tool-capable)     →  Sub-Agents (Pollinations, tools-free)
├─ opencode-go/deepseek-v4-flash →  @kodcu (minimax)
├─ opencode/big-pickle           →  @analist (glm)
└─ opencode/deepseek-v4-flash-free → @yazar (gpt-5.4-mini)
                                   →  @yardimci (gemma)
```

## Key Technical Discoveries

### 1. OpenCode + Pollinations Works
- Custom provider with `@ai-sdk/openai-compatible` npm package
- `opencode run -m pollinations/minimax "prompt"` → API call succeeds
- Response is written to `~/.local/share/opencode/opencode.db`

### 2. Silent stdout Issue
- `opencode run` only shows `> build · model` header on stderr
- Text responses go to SQLite DB, NOT stdout
- `--format json` only emits tool-related events (step-start), not text
- **Workaround**: `oc_wrapper.py` reads DB after each run

### 3. Bug #26394 — Sub-Agents Get NO Tools
- When primary agent delegates via `task` tool → sub-agent receives `tools: []`
- **Beneficial**: Pollinations models don't support tools → payload stays small
- Sub-agent generates text → primary agent reads it

### 4. Primary Agent MUST Be Tool-Capable
- Pollinations models cannot delegate to `@agent_name` (no function calling)
- Need OpenCode Go/Zen free models as primary agent
- `@analist` from minimax primary → no session created, no error

### 5. Cloudflare 1010 UA Block
- Pollinations and Go API both block non-browser User-Agents
- Python `urllib` → 403 error 1010
- `curl` with standard UA → 403
- Browser UA `Mozilla/5.0...` → works
- **Solution**: Local proxy on port 19999 adds browser UA

## Agent Files

Created in `~/.config/opencode/agents/`:

| File | Model | Role | Temp |
|------|-------|------|------|
| `kodcu.md` | pollinations/minimax | Code generation | 0.2 |
| `analist.md` | pollinations/glm | Research/analysis | 0.3 |
| `yazar.md` | pollinations/gpt-5.4-mini | Creative writing | 0.8 |
| `yardimci.md` | pollinations/gemma | General helper | 0.5 |

All agents have `permission: {edit:deny, bash:deny, write:deny, task:deny, todowrite:deny}`.

## Model Quality Comparison

| Role | Pollinations (free) | OpenCode Go Free (200req/5h) | Winner |
|------|---------------------|------------------------------|--------|
| Kodcu | **MiniMax M2.7** (SWE-bench 80.2%) | DeepSeek V4 Flash Free (SWE-bench ~79%) | Pollinations |
| Analist | **GLM-5** (MMLU 91.7%) | DeepSeek V4 Flash Free (MMLU ~85%) | Pollinations |
| Yazar | **GPT 5.4 Mini** (Turkish tests best) | MiMo V2.5 Free | Pollinations |
| Yardimci | **Gemma 3** (vision, lightweight) | Nemotron 3 Super Free | Pollinations |

## OpenCode Go Fallback

When Pollinations pollen runs out, switch to OpenCode Go paid tier ($5 first month, $10/month):
- Kodcu: `opencode-go/minimax-m2.7` (3,400 req/5h)
- Analist: `opencode-go/glm-5.1` (880 req/5h)

## Proxy Setup

Dual-purpose proxy at `http://127.0.0.1:19999`:
- `/v1/*` → Pollinations (`https://gen.pollinations.ai/v1/*`)
- `/go/v1/*` → OpenCode Go (`https://opencode.ai/zen/go/v1/*`)
- Adds browser UA to all requests
- Auto-injects API keys when client doesn't send them
- Translates `/v1/responses` → `/v1/chat/completions` for OpenCode compatibility

## Auth Issues

- `OPENCODE_API_KEY` env var: shows Go models in `opencode models` but `opencode run` fails with "Invalid API key"
- `auth.json` format `{"opencode-go":"key"}`: shows 0 credentials in `opencode auth list`
- Proper auth: `/connect` in TUI → select OpenCode Go → paste key
- Secret redaction blocks key from tool-call parameters