## Pollinations Proxy Diagnostics

## Mimari (Güncel)

Hermes iki ayrı servis üzerinden Pollinations API'ine bağlanır:

| Port | Servis | Başlatma | Restart |
|------|--------|----------|---------|
| **19999** | `pollinations-proxy.py` → `gen.pollinations.ai` | `hermes-pollinations-proxy.service` (systemd user) | `Restart=always`, 3sn |
| **8642** | Hermes Gateway | `hermes-gateway.service` (systemd user) | `Restart=always`, 5sn |

İkisi `PartOf` ilişkisiyle bağlı değildir — biri çökerse diğeri etkilenmez.

## Proxy Systemd Service

**Unit file:** `~/.config/systemd/user/hermes-pollinations-proxy.service`

```ini
[Unit]
Description=Hermes Pollinations Proxy — 127.0.0.1:19999 → gen.pollinations.ai
After=network-online.target
Wants=network-online.target
PartOf=hermes-gateway.service

[Service]
Type=simple
ExecStart=/home/ubuntu/.hermes/hermes-agent/venv/bin/python3 /home/ubuntu/.hermes/scripts/pollinations-proxy.py
Restart=always
RestartSec=3
KillMode=process
TimeoutStopSec=10

[Install]
WantedBy=default.target
```

**Özellikler:**
- `Restart=always` — herhangi bir sebepten ölürse 3sn içinde ayağa kalkar
- `PartOf=hermes-gateway.service` — gateway durdurulursa proxy de durur (ama tersi çalışmaz)
- Gateway'den bağımsız: gateway crash'i proxy'i etkilemez
- Sistem reboot'unda `systemctl --user enable` ile otomatik başlar

## Proxy Management (infra.sh)

`~/.hermes/scripts/infra.sh` aşağıdaki proxy komutlarını destekler:

| Komut | Ne yapar? |
|-------|-----------|
| `proxy-restart` | Proxy'i restart et + HTTP test |
| `proxy-status` | Proxy systemd status |
| `proxy-start` | Proxy'i başlat |
| `proxy-stop` | Proxy'i durdur |
| `full-restart` | Önce proxy, sonra gateway restart |
| `full-status` | Gateway + Proxy durumlarını göster |
| `health` | Gateway HTTP + Proxy HTTP test |

## Post-Update Fix

Güncelleme (`/update`) sonrası `post-update-fix.sh` otomatik çalışır:

```bash
cd ~/.hermes/hermes-agent && git pull && pip install -e . && bash ~/.hermes/scripts/post-update-fix.sh
```

**post-update-fix.sh** şunları yapar:
1. `.env`'de `POLLINATIONS_API_KEY` var mı kontrol et
2. Proxy service aktif mi kontrol et (değilse başlat)
3. Proxy'e test isteği gönder (HTTP 200 mü?)
4. 200 değilse restart et + tekrar test et

## Hata Türüne Göre Yönlendirme

### 401 — Pollinations modellerinde (`Authentication required`)

Log: `Error code: 401`, mesaj `Authentication required`

**Kök neden:** Proxy'deki API key geçersiz/expired. Proxy `.env` → `POLLINATIONS_API_KEY` okur.

**Teşhis:**
```bash
# Proxy çalışıyor mu?
systemctl --user is-active hermes-pollinations-proxy

# Proxy test
curl -s -w '\nHTTP:%{http_code}' --connect-timeout 10 --max-time 25 \
  http://127.0.0.1:19999/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"openai","messages":[{"role":"user","content":"ping"}],"stream":false}'

# Gateway log
journalctl --user -u hermes-gateway --since "today" | grep -i "401\|pollinations\|auth"
```

**Onarım:**
1. `POLLINATIONS_API_KEY`'i `.env`'de güncelle (`chmod 600`)
2. `bash ~/.hermes/scripts/infra.sh proxy-restart`
3. Doğrula: proxy test → HTTP 200

### 401 — Gateway (port 8642, `Invalid API key`)

Gateway ana provider'ı (deepseek) için API key sorunu. Session'ı etkilemez — gateway deepseek yeni session'lar ve cron job'lar için kullanılır.

**Onarım:** `bash ~/.hermes/scripts/infra.sh gateway-restart`

## Hızlı Sağlık Kontrolü

```bash
# Tek satırda her şey
bash ~/.hermes/scripts/infra.sh full-status
# veya
bash ~/.hermes/scripts/infra.sh health
```

## Proxy Detayı

Script: `~/.hermes/scripts/pollinations-proxy.py`
- Hedef: `https://gen.pollinations.ai`
- Port: `19999`
- API key: `.env` → `POLLINATIONS_API_KEY`
- Responses API → Chat Completions dönüşümü
- Desteklenmeyen endpoint'lere mock (`/api/tags`, `/v1/models`, `/api/show`)
