---
name: headless-browser-auth
description: "Headless browser cookie authentication for services without API auth — Playwright Chromium CDP, cookie import/refresh, auto-refresh cron jobs."
category: devops
triggers:
  - notebooklm auth expired
  - cookie auth stale
  - nlm login failed
  - headless chrome cdp setup
  - cookie refresh cron
---

# Headless Browser Cookie Auth

For services that **only support browser-based authentication** (NotebookLM, some internal tools, Google Workspace add-ons), use headless Playwright Chromium with CDP for automated cookie refresh.

## Core Pattern

1. Start headless Chrome with CDP (no X server needed)
2. Connect auth CLI via CDP (`nlm login --cdp-url`)
3. Import cookies to service's credential store
4. Set up periodic cron refresh (every 12h)

## Playwright Chromium (No Xvfb)

The snap `chromium-browser` has X11/Xauthority issues on headless servers. **Use Playwright's standalone Chromium instead:**

```bash
# Find the binary
find ~/.cache/ms-playwright -name "chrome" -path "*/chrome-linux/*"
# Typical path: ~/.cache/ms-playwright/chromium-1223/chrome-linux/chrome
```

### Start Headless Chrome with CDP

```bash
CHROME=~/.cache/ms-playwright/chromium-1223/chrome-linux/chrome
$CHROME --headless=new --no-sandbox --disable-gpu \
  --disable-dev-shm-usage --remote-debugging-port=9222 \
  --user-data-dir=/tmp/chrome-profile --no-first-run \
  --disable-default-apps about:blank
```

Key flags:
- `--headless=new`: No X server needed
- `--remote-debugging-port=9222`: CDP endpoint
- `--user-data-dir`: Persistent profile for cookies
- **No DISPLAY, no XAUTHORITY, no Xvfb required**

## Cookie Auth Patterns

### Pattern A: nlm login with CDP

```bash
nlm login --cdp-url http://127.0.0.1:9222 --force
```

### Pattern B: Manual cookie import

Export cookies from a real browser as JSON, then:

```bash
nlm login --manual -f /path/to/cookies.json
```

Update auth.json with CSRF token and session ID from metadata.

### Pattern C: Full refresh script

In `refresh_cookies.py`:
1. `nlm login --check` → if valid, update auth.json and exit
2. If expired → start headless Chrome → `nlm login --cdp-url` → update auth.json
3. If all fails → alert for manual intervention

### Pattern E: Cloudflare Bot Management bypass via cookie injection (Enterprise sites)

For sites behind **Enterprise-tier Cloudflare Bot Management** (Upwork, etc.), browser automation always fails on form submit. The only working bypass is cookie injection from a real browser session.

See `references/cloudflare-bot-mgmt-cookie-bypass.md` for:
- Complete Camoufox implementation (Node.js)
- SameSite normalization (required for Playwright)
- ARM64 compatibility notes
- Comparison table of all tested methods

```javascript
// Quick start: load cookies into Camoufox BEFORE navigation
const cookies = JSON.parse(fs.readFileSync('/tmp/cookies.json'));
await page.context().addCookies(cookies);
await page.goto('https://target-site.com');
```

### Pattern D: Manual cookie import (FALLBACK — en güvenilir)

CDP WebSocket 403 hatası alındığında (%100 başarısızlık oranı) veya Chrome profili boş olduğunda:

```bash
nlm login --manual -f /path/to/cookies.json
```

CookieFile her iki formatı destekler: Netscape (cURL) veya JSON (Chrome extension export).

**Ne zaman kullan:** CDP `--remote-allow-origins=*` Chrome 148'de çalışmazsa, ilk kurulumda, kullanıcı tarayıcısında oturum açmışsa.

## Auto-Refresh Cron Setup

### 1. Place refresh script in `~/.hermes/scripts/`

```bash
#!/bin/bash
# nlm-auth-refresh.sh
NLM_BIN=~/.local/bin/nlm
AUTH=$($NLM_BIN login --check 2>&1)
if echo "$AUTH" | grep -qi "valid"; then exit 0; fi
python3 ~/.nlm/refresh_cookies.py
```

### 2. Register as no_agent cron job

Schedule every 12 hours (0 */12 * * *), script-based, no LLM tokens consumed.

## File Locations

| Location | Content |
|----------|---------|
| `~/.notebooklm-mcp-cli/profiles/default/` | cookies.json, metadata.json |
| `~/.notebooklm-mcp-cli/auth.json` | MCP auth (generated) |
| `~/.nlm/refresh_cookies.py` | Headless refresh script |
| `~/.nlm/check_auth.sh` | Auth check + refresh wrapper |

## AuthHealthChecker Architecture (v0.7.1+)

AuthHealthChecker (`services/auth.py`) uses a **two-phase probe strategy**:

1. **Phase 1 — Homepage probe:** HTTS GET to `notebooklm.google.com/` with browser-like headers (`_PAGE_FETCH_HEADERS`: UA, Accept, Sec-Fetch-*). Checks if response URL contains `accounts.google.com` (redirect = expired) or returns non-200.
2. **Phase 2 — API fallback (only if Phase 1 fails):** Creates a `NotebookLMClient` and calls `list_notebooks()`. The API endpoint (`notebooklm.google.com/api/...`) is more lenient than the homepage and often accepts cookies that the homepage rejects.

```python
# Simplified flow:
probe = _probe_homepage(cookies)  # → notebooklm.google.com/
if probe.valid:                    return "configured"
if probe.reason == "expired":       # ← accounts.google.com redirect
    api_probe = _probe_api(cookies) # → list_notebooks()
    if api_probe.valid:             return "configured"  # false positive avoided!
# Both failed:
return "stale"
```

**Important:** In v0.7.1, the homepage probe already hits `notebooklm.google.com/` (NOT `www.google.com`), using proper browser-like headers including Sec-Fetch-*. This was fixed upstream — no manual probe URL patching needed.

**Key insight for "stale" diagnosis:** If BOTH probes fail, the "stale" status is accurate — it's not a false positive. The API probe (`list_notebooks`) shares the same authentication as CLI read operations (`nlm login --check`), so if both fail, auth is genuinely broken.

### Diagnostics: Stale But Cookies Non-Expired

A common confusing scenario: `cookies.json` shows 61 cookies with valid expiry dates, but both probes return "stale". **This means Google has actively revoked the session** — cookie expiry dates are the *maximum* lifetime, not a guarantee.

Common causes:
- Password changed on any device using this Google account
- Google account security event (suspicious login detection, new device login)
- Session manually revoked from Google Account settings
- Cookie rotation (Google replaces session cookies periodically)

**Diagnostic flow:**
```
1. Check cookie expiry → all valid → session was revoked, not expired
2. Check nlm login --check → fails → confirms genuine auth failure
3. Solution: User must re-export cookies from a trusted browser
```

### Verifying External AI Analysis

External AI analysis of code issues (like GLM-5.1's auth analysis) should always be **validated against the actual source code** before applying patches. Plausible-sounding claims about missing headers or wrong endpoints can be confidently debunked by reading `services/auth.py`, `core/auth.py`, and `core/base.py`.

## Pitfalls

- **Snap Chromium** has X11 issues on headless servers → use Playwright Chromium
- **"stale" with `live=False`** is a heuristic (7-day), but **"stale" with `live=True`** (both probes run) is an accurate verdict — check which mode was used
- **"stale with valid cookies"**: if cookies are non-expired but both probes fail, the session was actively revoked by Google — re-export is the only fix
- **ProcessSingleton error** → lock files from crashed Chrome. Fix: `rm -f {profile_dir}/Singleton*`
- **nlm login --cdp-url** needs a profile with existing Google session cookies
- **Manual import (--manual)** is always available as fallback
- **Auth expiry**: verify with actual write operations (`nlm report create ... --confirm -y`), not just `--check`
- **Cron auth_monitor.sh false-positive DOWN alarms:** `systemctl --user is-active` user crontab icinde `XDG_RUNTIME_DIR` set edilmedigi icin sessizce basarisiz olur → servis calisiyor olsa bile "DOWN" raporlanir. Cozum: `export XDG_RUNTIME_DIR=/run/user/$(id -u)` ve `export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/$(id -u)/bus` script basinda. Detay: `references/cron-systemd-user-pitfall.md`

### 🚨 ARM64 Chromium Binary Yolu (Playwright Headless Shell)

Bu sunucu **Oracle Cloud ARM64 (aarch64)** üzerinde çalışır. Playwright'ın `chromium` paketi ARM64 için `chrome` binary'si içermez — bunun yerine `headless_shell` kullanılır.

**Binary yolu:**
```
~/.cache/ms-playwright/chromium_headless_shell-1223/chrome-linux/headless_shell
```

**Doğrulama:**
```bash
file ~/.cache/ms-playwright/chromium_headless_shell-1223/chrome-linux/headless_shell
# → ELF 64-bit LSB pie executable, ARM aarch64
```

**Playwright ile kullanım:**
```python
from playwright.async_api import async_playwright
async with async_playwright() as p:
    browser = await p.chromium.launch(
        headless=True,
        executable_path='/home/ubuntu/.cache/ms-playwright/chromium_headless_shell-1223/chrome-linux/headless_shell',
        args=['--no-sandbox', '--disable-dev-shm-usage']
    )
```

**Önemli farklar:**
| Özellik | x86_64 (standart) | ARM64 (bu sunucu) |
|---------|-------------------|-------------------|
| Binary | `chrome` | `headless_shell` |
| Dizin | `chromium-1223/chrome-linux/chrome` | `chromium_headless_shell-1223/chrome-linux/headless_shell` |
| Selenium `webdriver.Chrome()` | Çalışır | ❌ `Unsupported platform: linux/aarch64` |
| SeleniumBase UC driver | Çalışır | ❌ `Exec format error` (x86 binary) |

**Kural:** ARM64'te headless browser otomasyonu için **Playwright** kullan. Selenium ve SeleniumBase aarch64 desteklemez.

### 🚨 WebSocket CDP 403 (Chrome 148+)

`--remote-allow-origins=*` flag'i Chrome 148'de **çalışmaz** — WebSocket bağlantıları hala 403 Forbidden döner. Belirti:

```
WebSocketBadStatusException: Handshake status 403 Forbidden
```

Bu bir origin/sunucu güvenlik kısıtlaması — Chrome flag'i yetersiz kalıyor.

**Çözüm:** CDP'yi tamamen atla, `nlm login --manual -f cookies.json` kullan.

### 🚨 Cookie Deduplication (61→27 Kayıp)

`cookies.json` dosyasında aynı isimde farklı domain/path için birden fazla cookie bulunabilir (ör. 3 tane `HSID`, 3 tane `SID`). Ancak `cookies_to_header(cookies: dict[str, str])` fonksiyonu **dict** aldığı için aynı isimdeki cookie'lerden sadece sonuncusu kalır, diğerleri sessizce kaybolur.

**Etkisi:** 61 cookie → 27 cookie. Kritik domain-specific cookie'ler (ör. notebooklm.google.com'a özel SID) ezilmiş olabilir.

**Belirti:** Cookie'ler yeni ve expiry süreleri geçerli olmasına rağmen `nlm login --check` fail. `_fetch_notebooklm_homepage`'te gönderilen Cookie header'ı eksik.

**Teşhis:**
```python
cookie_dict = {c["name"]: c["value"] for c in cookies if "name" in c and "value" in c}
print(f"Düşüş: {len(cookies)} → {len(cookie_dict)}")
```

**Çözüm:** Bu `notebooklm-mcp-cli` kütüphane seviyesinde bir sınırlama. Alternatif yok — kütüphane internal'da dict kullanıyor. En güvenilir yol: kullanıcının Chrome'undan export (gerçek Chrome tüm duplicate cookie'leri doğru yönetir) + `nlm login --manual`.

### 🚨 `nlm login --manual` Sessiz CSRF Bozulması

`nlm login --manual -f cookies.json` çalıştığında:
1. Cookie'ler başarıyla import edilir ✅
2. CSRF token'ı extract etmek için `_fetch_notebooklm_homepage()` çağrılır
3. Homepage `accounts.google.com`'a redirect olursa → sayfa login sayfasıdır, NotebookLM içeriği değil
4. CSRF extractor yanlış elementi yakalar → **JavaScript fonksiyonu** (örn. `function(a){var b=this,c=Zl(`) CSRF olarak kaydedilir
5. CLI "Successfully authenticated!" yazar ama auth hala bozuktur

**Belirti:** `nlm login --manual` "başarılı" ama `nlm login --check` hala "expired". `auth.json`'da `csrf_token: "function(a){...}"`

**Teşhis:**
```bash
python3 -c "import json; a=json.load(open('~/.notebooklm-mcp-cli/auth.json')); print(a.get('csrf_token','')[:40])"
# → "function(a){var b=this,c=Zl("  → BOZUK!
```

**Kök neden:** `_fetch_notebooklm_homepage` accounts.google.com'a redirect olduğu için sayfa içeriği NotebookLM'e ait değil. CSRF extractor sayfadaki rastgele bir JavaScript fonksiyonunu yakalıyor.

**Ne yapmalı:**
- CLI "başarılı" dese bile `csrf_token`'ı doğrula
- Eğer CSRF bozuksa: manuel olarak NotebookLM sayfasından (`view-source:https://notebooklm.google.com/`) `_csrftoken` değerini al ve `auth.json`'a yaz
- En garantili yol: `nlm login --cdp-url` (gerçek Chrome oturumu ile) — cookie'ler ve CSRF birlikte doğru alınır

### 🚨 Auth Asimetrisi (Read ✅ / Write ❌)

Kritik: `nlm login --check` başarılı olsa bile yazma işlemleri bloke olabilir:

| İşlem | Durum |
|-------|-------|
| `notebook_list` | ✅ Çalışır |
| `notebook_query` | ✅ Çalışır |
| `source_add(type="text")` | ✅ Çalışır |
| `studio_create` (slide_deck, audio, report) | ❌ "expired" |
| `nlm report create` | ❌ PERMISSION_DENIED (code 7) |

**Nedeni:** NotebookLM'in okuma ve yazma token'ları farklı sürelere sahip. CLI `--check` sadece okuma token'ını test eder. Yazma token'ı daha hızlı expire olur.

**Doğrulama prosedürü:** `nlm login --check` yerine doğrudan yazma testi yap:
```bash
nlm report create <NOTEBOOK_ID> --format "Briefing Doc" --confirm -y
```
PERMISSION_DENIED alırsan yazma kapalıdır. Sadece `--check` valid demek yetmez.

**Belirtiler:**
- MCP `refresh_auth: {"status":"expired"}` → sadece 7-gün heuristic DEĞİL, gerçekten expired
- `nlm login` valid dedikten sonra hala PERMISSION_DENIED

## Verification

```bash
# 1. CLI auth check (read-only — yetersiz!)
nlm login --check

# 2. WRITE testi (zorunlu! — read check yetmez)
# Bir notebook ID al, sonra:
nlm report create <NOTEBOOK_ID> --format "Briefing Doc" --confirm -y
# PERMISSION_DENIED → yazma kapalı, yeniden auth gerek

# 3. MCP server status (canlı)
mcp_notebooklm_mcp_server_info
# auth_status: "stale" → gerçek expired olabilir, write test yap

# 4. Service operations test
# Read: notebook_list, notebook_query (genelde çalışır)
# Write: studio_create (sorunlu, test et)
```
