---
name: hermes-config-resilience
title: Hermes Config Resilience
description: Preserve Hermes Agent config across updates using golden_config.yaml and restore_config.py
trigger: User mentions golden_config, config reset after update, or post-update hook issues
---

# Hermes Config Resilience

Preserve Hermes config across updates. Uses `golden_config.yaml` as single source of truth and `restore_config.py` with `--post-update` mode.

## Architecture

`hermes update` → `post-update.sh` hook → `restore_config.py --post-update`

Pipeline: snapshot → sync golden from config → check drift → restore golden values → restart gateway → verify

## Commands

| Command | Action |
|---------|--------|
| `--check` | Dry-run diff, exit 0=aligned 1=drift |
| `--sync` | Add new config entries to golden |
| `--restore` | Sync + apply golden to config preserves version metadata |
| `--post-update` | Full pipeline + gateway restart + verify |

## Critical Rules

1. `_config_version` never overwritten
2. API keys empty in golden (from .env or Bitwarden)
3. **Bitwarden enabled MUST be true in golden** — after setting up Bitwarden SM, golden_config.yaml has `secrets.bitwarden.enabled: false` by default. MUST manually set to `true` in golden, then `--restore` to apply. If golden says `false`, every `--restore` will DISABLE Bitwarden.
4. SOUL/AGENTS section-merged (user additions preserved)
5. `hooks_auto_accept: true` required

## Pitfalls

- **Bitwarden + Golden cycle:** Setup Bitwarden → `--sync` → edit golden to set `secrets.bitwarden.enabled: true` → `--restore`. Don't skip the golden edit step.
- **`--restore` after update:** If the update added new config keys, `--sync` first, then `--restore`. Never `--restore` without `--sync` — you'd lose the new keys.
- **`--check` exit code:** Exit 0 = aligned, exit 1 = drift. Use this in automation.
- **`_config_version` increase:** If Hermes update bumps `_config_version` and golden blocks it during restore, check if a migration is expected. `_config_version` 23 at time of writing.
- **Run `--check` BEFORE `--restore`** — always see the diff first. This session found 32 diffs after Bitwarden setup; most were harmless ordering diffs, but `secrets.bitwarden.enabled: false` in golden was critical. If `--restore` had run without first fixing golden to `true`, Bitwarden would have been disabled.
- **After new provider/model alias:** `--sync` then `--check`. New custom providers or model_aliases won't be in golden until synced.
- **Adding custom providers (Hermes config):** When `hermes config` CLI doesn't support the operation, use `python3` with `yaml` to edit `custom_providers` and `model_aliases` programmatically. Then run `restore_config.py --sync` to update golden. Always `systemctl --user restart hermes-gateway` after provider changes. The `api_key_env` references a Bitwarden secret name. See voice-agent reference for Groq integration example.

## Setup

1. Make post-update hook executable
2. Enable `hooks_auto_accept` in config
3. `python3 scripts/restore_config.py --sync`
4. `python3 scripts/restore_config.py --check`
5. `python3 scripts/restore_config.py --restore`

## Maintenance

- After new provider: `--sync` then `--check`
- After broken update: `--check` then `--restore`
- Golden can be manually edited
- Always `--check` after any update
