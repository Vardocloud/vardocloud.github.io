---
name: hermes-api-performance
description: "Hermes API latency diagnostics — provider comparison, context overhead measurement, voice agent feasibility testing"
version: 1.0.0
metadata:
  hermes:
    tags: [hermes, api, latency, performance, provider, voice]
    category: devops
---

# Hermes API Performance Diagnostics

Latency measurement and provider comparison for Hermes API.

## Core Finding

Hermes API response time varies significantly by provider:
- **Groq LPU (BEST for voice):** ~7.5s total via Hermes custom_provider. llama-4-scout-17b. Fast streaming, excellent Turkish. No throttling observed.
- **Pollinations:** 5-20s, throttles on consecutive requests. `openai` model ~4.5s first call, degrades to ~20s by 3rd-4th call.
- **opencode-go (deepseek):** 2-3s for flash models, 20-50s for reasoning models.

Context assembly overhead (3-4s) is provider-independent. Streaming masks this: first token arrives while context is still loading.

## Diagnostic Pattern

```
1. Test provider DIRECTLY (bypass Hermes) → baseline inference speed
2. Test SAME model THROUGH Hermes API → context-added total
3. Difference = context assembly overhead
4. If difference is large → problem is context size, not provider
```

### Test Commands

Direct proxy test uses local proxy port. Hermes API test uses the gateway port with API key from env.

Streaming TTFT (time-to-first-token) is a better metric than total response time for voice applications. Measure with `stream: true`.

## Provider Switching

To switch default model and provider:

```
hermes config set model.default <model_name>
hermes config set model.provider <provider_name>
systemctl --user restart hermes-gateway
```

Always restart gateway after config changes. Verify with a test request.

### Adding Custom Providers (e.g., Groq)

Hermes config.yaml `custom_providers` supports OpenAI-compatible APIs:

```yaml
custom_providers:
  - api_key_env: GROQ_API_KEY
    api_mode: chat_completions
    base_url: https://api.groq.com/openai/v1
    models:
      groq-llama-4-scout: llama-4-scout-17b-16e-instruct
    name: Groq
```

Also add model aliases for shorthand: `groq: {model: groq-llama-4-scout, provider: Groq}`.

After adding, restart gateway. Model is immediately available via `/v1/chat/completions` with `model: groq-llama-4-scout`.

## Voice Agent Feasibility

For real-time voice (sub-2 second total response), Hermes API with full context is not suitable. The constraint triangle:

- **Fast** (under 2 seconds)
- **Full context** (memory, tools, skills)
- **Full capability** (server access, file operations)

Only two can coexist. Pick based on use case:
- Voice conversation → sacrifice full context (use light endpoint or external fast model)
- Deep work → accept 4-6 second response (use full Hermes API)
- Quick chat → external fast model with personality prompt

## Pitfalls

- **Don't diagnose without measuring:** HTTP 403 can be IP ban OR rate-limit. Check error body for code before concluding.
- **HTTP 502 from Hermes:** Provider routing failure. Verify model name exists in provider's model list.
- **Timeout:** Provider may be down. Test direct proxy connection first.
- **Streaming TTFT misleading:** TTFT measures time from when provider receives request, not from user submission. Context assembly still happens before streaming begins.
- **Provider change requires restart:** Config changes don't take effect until gateway restart.
- **`openai-fast` misnomer (2026-06-16):** Despite its name, `openai-fast` is the SLOWEST model on Pollinations (23s). `openai` (standard) is 5× faster at 4.5s. Do not select models by name — always measure.
- **Pollinations consecutive-request throttling (2026-06-16):** First call after idle: ~5s. By the 3rd-4th consecutive call: ~20s. This is server-side rate limiting, not a client bug. For voice agents, this means the first response is fast but rapid back-and-forth degrades. Mitigation: accept the latency range or switch provider.
- **Timeout chain alignment (2026-06-16):** In multi-hop architectures (voice agent → proxy → Hermes), upstream timeout MUST exceed downstream timeout + buffer. If voice agent times out at 20s while proxy waits 35s for Hermes, the user sees "proxy 500" but the real failure is upstream timeout misalignment. Rule: `T_upstream ≥ T_downstream + 5s`.
