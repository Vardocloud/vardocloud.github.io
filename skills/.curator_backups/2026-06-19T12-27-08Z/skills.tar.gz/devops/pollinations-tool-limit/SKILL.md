---
name: pollinations-tool-limit
description: "Pollinations gpt-5.4-mini 128 tool limit workaround — enabled_toolsets ile çözüm"
---

# Pollinations Tool Limit Workaround

**Date discovered:** 2026-06-08

## Problem

Pollinations' `gpt-5.4-mini` model routes through azure-openai backend (`gen.myceli.ai`) which enforces a strict **128 tool maximum**. Hermes Agent defines 135+ tools by default, causing a 400 Bad Request error:

```
azure-openai error: Invalid 'tools': array too long.
Expected an array with maximum length 128, but got an array with length 135 instead.
```

## Root Cause

The upstream azure-openai backend at `gen.myceli.ai` has a hard limit of 128 entries in the `tools` array of chat completion requests. This is not a Pollinations limitation — it comes from the Azure-hosted GPT-5.4 Mini model.

## Solution: enabled_toolsets

Set `enabled_toolsets` on the cron job to load only the tools actually needed. Hermes' `get_tool_definitions()` in `model_tools.py` **filters tool definitions before sending them to the API** — only tools from enabled toolsets appear in the API request.

For LinkedIn post automation, the needed toolsets are:

```yaml
enabled_toolsets: ["terminal", "web", "file", "search", "delegation"]
```

This reduces the tool count from ~135 to ~15-20, well under the 128 limit.

## How enabled_toolsets Filters Tools

In `/data/ubuntu/hermes-agent/model_tools.py`, `_compute_tool_definitions()` handles this:

```python
if enabled_toolsets is not None:
    # Only include tools from explicitly enabled toolsets
    for toolset_name in effective_enabled_toolsets:
        resolved = resolve_toolset(toolset_name)
        tools_to_include.update(resolved)
else:
    # Default: include ALL tools from ALL toolsets
    for ts_name in get_all_toolsets():
        tools_to_include.update(resolve_toolset(ts_name))
```

Key insight: `enabled_toolsets` does NOT just hide tools from the agent — it **removes them from the function definitions** sent to the model API. That's why it solves the 128-tool limit.

The cron scheduler passes `enabled_toolsets` from the job config to `AIAgent`, which passes it to `get_tool_definitions()`.

## Verified Threshold

Tested directly against the Pollinations proxy (`http://127.0.0.1:19999/v1`):

| Tools | Result |
|-------|--------|
| 128 | ✅ Works (model=gpt-5.4-mini-2026-03-17) |
| 129 | ❌ 400 Bad Request |
| 130 | ❌ 400 Bad Request |
| 135 | ❌ 400 Bad Request |

## Cron Job Configuration

Both LinkedIn cron jobs fixed with:

```bash
cronjob(action='update', job_id='272dc0178605',
        enabled_toolsets=["terminal","web","file","search","delegation"],
        model={"model":"gpt-5.4-mini","provider":"custom:Pollinations"})

cronjob(action='update', job_id='79aa6f693b23',
        enabled_toolsets=["terminal","web","file","search","delegation"],
        model={"model":"gpt-5.4-mini","provider":"custom:Pollinations"})
```

## Affected Jobs

| Job | ID | enabled_toolsets | Status |
|-----|-----|-----------------|--------|
| linkedin_sabah (09:00) | `272dc0178605` | `["terminal","web","file","search","delegation"]` | ✅ Fixed |
| linkedin_aksam (20:30) | `79aa6f693b23` | `["terminal","web","file","search","delegation"]` | ✅ Fixed |
| morning_greeting (07:00, 2026-06-08) | `morning_greeting` | `["terminal","web","file","search"]` | ✅ Fixed (daha az toolset yeterli — delegation gerekmez) |
| skool-daily-check (09:15, 2026-06-08) | `50002951d6bc` | Had `["terminal","web","browser","file","search"]` | ⚠️ MCP bypass → switched to `deepseek-v4-flash-free` |

## Toolset Selection Guide

| Job Type | Minimum enabled_toolsets | Reason |
|----------|-------------------------|--------|
| LinkedIn posting | `["terminal","web","file","search","delegation"]` | Web scraping + API calls + content writing |
| Morning greeting / routine text | `["terminal","web","file","search"]` | Calendar access + wiki reading only |
| Security / monitoring | `["terminal","file","web"]` | Port scanning + log reading |
| Skool / browser-based content checks | `["terminal","web","browser","file","search"]` | Login + scrape + notebooklm — **watch for MCP tool bypass** |

## ⚠️ Critical: Cron Job Prompt Design for gpt-5.4-mini

**Pitfall discovered 2026-06-08:** gpt-5.4-mini (via Pollinations) fails when:
- Skill loading is used (context ~30K chars → model overwhelmed → `[SILENT]` response)
- EKİP multi-agent curl workflow is specified (4+ complex steps too much for model)
- MCP tools are referenced (they're NOT available in cron jobs even with enabled_toolsets)

### Do's and Don'ts for LinkedIn Cron Jobs

**Don't:**
- ❌ Load skills in prompt (e.g., `linkedin-post:linkedin` skill = 30K chars → context overflow)
- ❌ Use EKİP curl workflow (Analist → Yazar → Yardımcı → Görsel = too many steps)
- ❌ Reference MCP tools (cron jobs can't see mcp_pollinations_generateImage etc.)
- ❌ Include long instructions or examples in prompt

**Do:**
- ✅ Embed essential rules directly in prompt (compact, 500-800 chars max)
- ✅ Give simple sequential instructions (5 adim maximum, straightforward)
- ✅ Use terminal + Python scripts for external API calls (Pollinations images, etc.)
- ✅ Include explicit "PAYLAŞMA, sadece üret ve göster" instruction
- ✅ Add writing style constraints inline (emoji yasak, #terapi yasak, Türkçapar stili vb.)

### Working LinkedIn Cron Prompt Pattern (8 Haz 2026)

The proven pattern removes skill loading and uses compact direct instructions:

```markdown
# LinkedIn [Sabah/Aksam] Postu

[Bardo Psychology icin psikoloji konulu bir LinkedIn postu hazirla.]

## Yazim Stili: Hakan Turkcapar
[Stil aciklamasi: akademik altyapili ama gunluk dil, sicak ve samimi, orneklerle somutlastir]

## Yazim Kurallari (UYGULA)
- 800-1500 karakter Turkce
- #terapi ve "terapi" kelimesi KULLANMA
- Emoji YASAK
- Soru/CTA ile bitirme YASAK
- "siz" hitabi YASAK
- Hashtag (3-5 adet icerikten turet, #psikoloji ekle)
- Her iddia icin kaynagi web_extract ile dogrula

## Is Akisi
1. web_search ile guncel psikoloji konusu bul
2. kaynagi web_extract ile oku, dogrula
3. post metnini yaz, /tmp/post.txt kaydet
4. yazim kurallarina uygunlugu kontrol et
5. Gorsel uret: terminal -> python3 ~/.hermes/scripts/linkedin_gorsel.py "prompt"

## Cikti Formatı
MEDIA:[gorsel yolu]

NOT: Paylasma, sadece uret ve goster. Edel onayi beklenir.
```

### Image Generation Script (~/.hermes/scripts/linkedin_gorsel.py)

Location: `~/.hermes/scripts/linkedin_gorsel.py` — standalone script for Pollinations image generation.

```
python3 ~/.hermes/scripts/linkedin_gorsel.py "post ana fikrini anlatan ingilizce prompt"
```

- Model: `seedream-pro` (better quality than kontext for LinkedIn)
- Dimensions: 1200x628
- API key: `POLLINATIONS_API_KEY` env var (NOT /tmp/pk.txt)
- Output: `/tmp/gorsel.jpg`
- Fallback: POST → GET with URL parameters

The script handles:
1. POST to `gen.pollinations.ai/v1/images/generate` (primary)
2. GET to `gen.pollinations.ai/image/{prompt}` (fallback)
3. Response parsing (JSON URL or binary image)

## MCP Tool Bypass (Discovered 2026-06-11)

**Key finding:** MCP server tools are ADDITIONAL to built-in tools and may NOT be filtered by `enabled_toolsets`. 

A cron job with `enabled_toolsets: ["terminal", "web", "browser", "file", "search"]` still sent **153 tools** to the API (128 limit exceeded). The extra tools beyond the expected ~135 come from MCP server tool registrations.

**Effective tool count formula:**
```
total = filtered_builtin_tools(enabled_toolsets) + sum(mcp_tools_per_server)
```

Even with aggressive `enabled_toolsets`, 5+ active MCP servers (~3-10 tools each) can push total past 128.

**Real-world data point (2026-06-11):** Skool-daily-check with `enabled_toolsets: ["terminal", "web", "browser", "file", "search"]` (5 toolsets) sent **153 tools**. This means ~25-30 tools came from active MCP servers (codegraph, context-mode, notebooklm-mcp, puppeteer, sqlite, local-secure, pollinations = 7 servers).

**Diagnosis:** When a job fails with `tools array too long` despite having `enabled_toolsets`:
- Check how many MCP servers are active in the current setup
- Each MCP server adds tools unconditionally to every request
- `filtered_tools + mcp_tools` must be ≤ 128

## Alternative Solution

If `enabled_toolsets` alone can't get below 128 (MCP tools push past limit), switch to a different model on the Pollinations provider that doesn't enforce the 128-tool limit:

```yaml
model: mistral         # 0.62s latency, Turkish-capable, no tool limit
provider: Pollinations # Or: llama (1.04s), openai (1.17s)
```

**⚠️ 2026-06-15: DO NOT use opencode-zen as fallback.** The opencode-zen provider (mimo-v2.5-free, deepseek-v4-flash-free) is rate-limited (HTTP 429) across all models. Pollinations proxy models (mistral/llama/openai) are proven fast and stable.

**Model speed reference (Pollinations proxy, 2026-06-15):**
| Model | Latency | Turkish |
|-------|---------|---------|
| mistral | 0.62s | ✅ |
| llama | 1.04s | ✅ |
| openai | 1.17s | ✅ |

## Azure Content Filter Workaround — Token Refresh

As of 2026-06-08, Pollinations' token refresh (new API key) resolved Azure content filtering issues for routine Turkish text. Previously, even benign prompts like `"Günaydın Edel! Bugün nasıl hissediyorsun?"` were blocked by Azure's content policy. After the token refresh, the same prompts work without issues.

**Pattern:** If a job fails with `content_policy_blocked` on Pollinations:
1. Check if a token refresh is pending/possible
2. If token is refreshed → try again
3. If still blocked → fall back to opencode-zen with `deepseek-v4-flash-free`

**Verification:** `morning_greeting` job (gpt-5.4-mini via Pollinations) successfully ran on 2026-06-08 with `enabled_toolsets: ["terminal","web","file","search"]` — no Azure filter errors.
