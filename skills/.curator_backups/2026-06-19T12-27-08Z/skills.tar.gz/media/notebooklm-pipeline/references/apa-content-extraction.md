# APA Content Extraction Notes

## Purpose
Practical extraction notes for APA Monitor / Press Releases pages when the page HTML structure changes or `main.innerText` is incomplete.

## Reliable extraction patterns
- Prefer browser console evaluation after the page fully renders.
- For Monitor article pages, `document.querySelector('main').innerText` may capture only navigation/sidebar content.
- Better fallback: collect paragraphs and filter short boilerplate.

## Recommended console expressions
```javascript
[...document.querySelectorAll('p')]
  .map(p => p.innerText)
  .filter(t => t.length > 50)
  .join('\n\n')
```

```javascript
document.querySelector('[role="main"]')?.innerText
```

## Notes
- Use the paragraph-filter fallback when article pages are article-heavy but sidebar-heavy.
- Keep the text in a structured form before passing it to writing/summary agents.
- For cron-style runs, extract only what is needed for the report; avoid trying to preserve every navigation crumb.
