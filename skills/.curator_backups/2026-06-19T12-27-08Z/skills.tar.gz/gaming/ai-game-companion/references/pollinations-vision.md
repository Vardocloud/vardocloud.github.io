# Pollinations Vision API

## Qwen VL Plus via Pollinations

**Endpoint:** `https://ai.pollinations.ai`

**Model:** `Qwen/Qwen2-VL-72B-Instruct` (Qwen VL Plus equivalent)

## Python Call Example

```python
import requests
import base64

def analyze_game_frame(image_path, prompt="Describe what you see in this game screenshot."):
    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
                {"type": "text", "text": prompt}
            ]
        }
    ]

    response = requests.post(
        "https://ai.pollinations.ai/v1/chat/completions",
        json={"model": "Qwen/Qwen2-VL-72B-Instruct", "messages": messages},
        timeout=60
    )
    return response.json()["choices"][0]["message"]["content"]
```

## Use Case Prompt for Game Companion

**Story/Dialog capture:**
```
prompt = "Bu oyun ekran görüntüsündeki dialog ve hikaye gelişmelerini analiz et. 
Karakter konuşmalarını, olay örgüsünü, ve önemli detayları Türkçe özetle."
```

**Scene description:**
```
prompt = "Describe this game scene briefly: characters present, actions, environment."
```

## Latency Notes
- Vision analysis: ~5-20 sec depending on image complexity
- Network: external PC → cloud server → Pollinations API
- Total roundtrip: ~10-30 sec for full analysis + reply

## Alternative: Gemini Flash Lite
```python
# If Qwen fails or is slow, fallback to gemini-flash-lite via vision_analyze tool
# But Edel prefers Qwen for this use case
```

## Screenshot on PC Side (mss)

```python
import mss
import requests

def capture_and_send(server_url):
    with mss.mss() as sct:
        screenshot = sct.grab(sct.monitors[1])  # primary monitor
        mss.to_png(screenshot.rgb, screenshot.size, output="frame.png")

    with open("frame.png", "rb") as f:
        files = {"file": f}
        requests.post(server_url, files=files)
```

## Server Endpoint (Flask)

```python
from flask import Flask, request
import requests

app = Flask(__name__)

@app.route("/game-frame", methods=["POST"])
def game_frame():
    file = request.files["file"]
    # save temporarily or process directly
    # call vision API
    # log to story file
    # send Telegram reply
    return "ok"
```