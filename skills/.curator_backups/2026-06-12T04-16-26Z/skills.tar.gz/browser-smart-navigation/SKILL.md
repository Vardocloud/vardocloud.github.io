---
name: browser-smart-navigation
description: "Web sitelerinde akıllı gezinme stratejisi. Buton, link ve içerikleri bulmak için decision tree + anti-repeat kuralları. Token tasarrufu sağlar, element kaçırmayı önler."
version: 1.0.0
author: Vanitas
metadata:
  hermes:
    tags: [browser, navigation, vision, efficiency, tokens, web]
    applies_to: [Vanitas]
    triggered_by: [browser-navigate, web-scraping, login, form-fill, browser-click, browser-snapshot]
---

# Akıllı Browser Gezinme

Butonları, linkleri ve içerikleri bulmak için sistematik yaklaşım. Token israfını önler.

## Karar Ağacı

Her sayfa yüklendiğinde bu sırayı izle:

### ADIM 1: Snapshot al (HER ZAMAN full=true)

`browser_snapshot(full=true)` — `full=false` KULLANMA

ref ID'leri kaydet (örn: @e5, @e12)

- Element bulundu mu? → `browser_click` / `browser_type` ile devam et
- HAYIR → ADIM 2'ye geç

### ADIM 2: Vision ile kontrol

`browser_vision` — ekran görüntüsünü analiz et

- Buton, form, link var mı?
- Bulduğun elementin pozisyonunu ADIM 1'deki ref ID ile eşleştir
- Bulamadıysan → ADIM 3'e geç

### ADIM 3: Console kontrolü

`browser_console` — JS hatalarını kontrol et

- Hata varsa → bekle (3-5 sn), ADIM 1'e dön
- Hata yoksa → ADIM 4'e geç

### ADIM 4: Aşağı kaydır

```
browser_scroll(direction="down")
browser_snapshot(full=true)
```

- Dynamic content için (Skool, Reddit, Twitter vs.)
- Yeni içerik geldi mi? → ADIM 1'e dön
- HAYIR → ADIM 5'e geç

### ADIM 5: Sayfa içi arama

`browser_get_images` + `browser_console`

- Resimleri listele, son hataları kontrol et
- Hala bulamadıysan → Sayfayı yeniden yükle veya URL kontrol et

## Anti-Repeat Kuralları (KRİTİK)

| Kural | Açıklama |
|-------|----------|
| URL tekrarı | Aynı URL'ye 2'den fazla kez navigate ETME |
| Snapshot limiti | Aynı sayfada 3'ten fazla snapshot ALMA |
| Vision limiti | Vision'ı 2'den fazla kullanma |
| Session hafızası | Her navigasyon öncesi: "Bu URL'ye zaten gittim mi?" diye sor |
| Session ID | Aynı session'da devam et, yeni session açma |

## Navigasyon Stratejisi

### ⚠️ Stale Ref ID Tuzağı (KRİTİK)

Sayfa state'i değiştiğinde (form açıldı, modal geldi, navigasyon oldu) **ESKİ snapshot'ın ref ID'leri geçersiz olur.** Eski ref'e tıklamak sayfayı bozabilir → "Unknown ref" hatası → sonraki snapshot boş gelir.

**Kural:** Her sayfa-state değişiminden SONRA yeni snapshot al. Önceki snapshot'tan ref ID'sini ezberleyip yeni sayfada kullanma.

**Kurtarma:**
1. `browser_snapshot(full=true)` dene — boş gelirse
2. Base URL'e yeniden `browser_navigate(url)` yap
3. Taze snapshot al, yeni ref ID'lerini kullan

### Basit sayfalar (haber, blog, wiki)

1. `browser_navigate(url)`
2. `browser_snapshot(full=true)` — metni oku
3. Bitti — `web_extract` daha hızlı olabilir

### Karmaşık sayfalar (Skool, LinkedIn, Twitter)

1. `browser_navigate(url)`
2. `browser_snapshot(full=true)` — elementleri bul
3. `browser_vision` — görsel kontrol
4. `browser_scroll(down)` — aşağı kaydır
5. `browser_snapshot(full=true)` — yeni elementler
6. Gerekirse `browser_click` ile devam et

### Login sayfaları

1. `browser_navigate(login_url)`
2. `browser_snapshot(full=true)` — input alanlarını bul
3. `browser_type(ref_id, email)` — email gir
4. `browser_type(ref_id, password)` — şifre gir
5. `browser_snapshot(full=true)` — submit butonunu bul
6. `browser_click(submit_ref_id)` — giriş yap
7. `browser_snapshot(full=true)` — başarılı mı kontrol et

### Form doldurma

1. `browser_snapshot(full=true)` — tüm input alanlarını listele
2. Her alan için `browser_type(ref_id, value)`
3. `browser_snapshot(full=true)` — submit butonunu bul
4. `browser_click(submit_ref_id)`

## Token Tasarruf İpuçları

1. **Önce web_extract dene** — Basit sayfalar için browser'dan hızlı ve ucuz
2. **full=true** — Tek seferde tüm sayfayı gör, birden fazla snapshot alma
3. **Vision'ı son çare olarak kullan** — Snapshot yetersiz kaldığında
4. **Console kontrol et** — JS hatalarını erken tespit et, gereksiz tıklamayı önle
5. **Scroll + snapshot** — Dynamic content için en etkili yöntem

## Hata Durumları

| Durum | Çözüm |
|-------|-------|
| Snapshot boş dönüyor | Sayfa henüz yüklenmedi → bekle, tekrar dene |
| Stale ref → "Unknown ref" hatası → sonraki snapshot boş | Sayfa state'i bozuldu → **base URL'e yeniden navigate et**. Eskimiş ref ID'lerini kullanma — her sayfa değişiminden sonra taze snapshot al. |
| ref ID bulamıyor | Vision ile kontrol et, elementin pozisyonunu bul |
| Click çalışmıyor | Element tıklanabilir olmayabilir → `browser_cdp` ile test et |
| Login başarısız | 2FA/CAPTCHA olabilir → `browser_vision` ile kontrol et |
| Cloudflare engeli | `engine: auto` kullan (Browserbase cloud IP) |
| Timeout | `browser_console` ile durumu kontrol et |

## Engine Seçimi Sayfası

| Platform | Önerilen Engine | Neden |
|----------|----------------|-------|
| Skool (Cloudflare) | `auto` | Browserbase residential IP |
| APA (Incapsula) | `auto` | Gerçek fingerprint |
| Google/YouTube | `chrome` + WARP | Cloudflare bypass |
| Instagram (Reels) | `chrome` | Login pop-up'ı kapat → vision ile içerik analizi. Pop-up'ı kapatmak için browser_snapshot ile ref ID bul, click et, sonra browser_vision. Ses yok — sadece görsel analiz. |

## Kombinasyon Örnekleri

### Skool'da içerik bulma

1. `browser_navigate("https://www.skool.com/...")`
2. `browser_snapshot(full=true)`
3. `browser_vision`
4. `browser_scroll(down)`
5. `browser_snapshot(full=true)`

### LinkedIn post paylaşma

1. `browser_navigate("https://www.linkedin.com/feed/")`
2. `browser_snapshot(full=true)`
3. `browser_click(@e5)` — "Start a post" butonu
4. `browser_type(@e12, "Post içeriği...")`
5. `browser_snapshot(full=true)`
6. `browser_click(@e15)` — Post butonu
