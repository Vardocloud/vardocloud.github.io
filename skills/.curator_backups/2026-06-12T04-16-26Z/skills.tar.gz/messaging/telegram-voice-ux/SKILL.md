---
name: telegram-voice-ux
version: 0.1.0
title: Telegram Voice UX (Hermes)
description: 'How to reliably get Hermes to return voice replies on Telegram using /voice modes, and how to debug when the UI doesn’t show expected voice bubbles.'
author: 'Vanitas (Edel)'
pinned: false
tags: [telegram, voice, tts, stt, elevenlabs, troubleshooting]
---

# Telegram Voice UX (Hermes)

## Goal
Make Telegram voice conversations feel natural: when the user sends **voice messages**, Hermes should respond with **voice messages** (Telegram voice bubbles), not only text.

## Relevant Hermes commands
- `/voice on` — voice reply to **voice messages only**
- `/voice off` — text-only replies (default)
- `/voice tts` — **auto-TTS all replies** (not ideal for “real chat” feel)
- `/voice status` — show current voice mode

## When to use
Use this skill whenever:
- The user prefers realistic chat flow: *user sends voice → assistant replies voice*
- The user complains that voice was generated but didn’t show as a voice bubble, or previous voice tests didn’t appear correctly.

## Core interaction pattern (realistic flow)
1. Ensure voice mode is set to **/voice on**.
2. Always test by sending a **short voice message** (1–2 sentences).
3. Validate that Hermes responds with a **Telegram voice bubble** (not just a text “read-out” preview).
4. If the assistant is replying to a voice message with text only, gently suggest `/voice on` rather than leaving the user to guess.
5. If voice bubble appears and is “birebir okunuyor” (same content), keep the setting; no need to switch to `/voice tts`.

## Debugging checklist: “Voice generated but chat shows text / nothing”
1. **Confirm mode**
   - Run `/voice status`.
   - If mode is not `voice-only`, switch accordingly (prefer `/voice on` for realism).
2. **Verify the trigger**
   - In `voice-only` mode, a *text* message from the user may produce **text** replies.
   - The user must send a **voice message** to trigger voice output.
3. **Telegram UI discrepancy**
   - If Hermes reports/produces a TTS audio internally but earlier messages didn’t show as voice bubbles, assume **Telegram rendering/UI timing or message-type formatting** differences.
   - Repeat with a single short voice test and re-check.
4. **Only if necessary**
   - Use `/voice tts` temporarily to force voice output for all replies if debugging proves the voice pipeline works but trigger mapping is off.
   - After confirmation, switch back to `/voice on` to preserve the natural chat UX.

## Pitfalls
- **Don’t keep `/voice tts` as the default** when the goal is realism; it yields less “human chat” behavior (assistant speaks even when user wrote text).
- Voice-mode commands differ by surface (CLI vs messaging). Always use the messaging ones (`/voice ...`) inside Telegram.

## Verification
- After setting `/voice on`, send a short voice message like: "Test tamam."
- Confirm the assistant response arrives as a **voice bubble** and the spoken content matches the intended transcript.

## STT Testing (faster-whisper)

### Critical: Do NOT test with synthetic audio
TTS → STT loop (Pollinations TTS → faster-whisper) is **not a valid test**. Synthetic speech is too clean — no background noise, no natural pauses, no accent variation. It always passes and gives false confidence.

### Valid STT test methods
1. **YouTube transcript test**: Download audio from a real YouTube video → transcribe → compare with actual speech. Tests real-world factors: music, multiple speakers, colloquial speech.
2. **User voice message**: Edel sends a voice message → STT transcribes → compare. Tests actual use case: Turkish, conversational speed, background noise.

### Setup reference
See `references/faster-whisper-setup.md` for installation, performance benchmarks, and test checklist.

## MEDIA File Sending
See `references/media-file-sending.md` for Telegram dosya gönderme rehberi (izinli dizinler, format desteği, debugging).
