---
name: apa-referenced-content
description: "APA kaynaklı içerik üretimi — LinkedIn post, blog, podcast. Spesifik referans kullanımı, makale tamamından beslenme, infographic görsel üretimi."
version: 1.0.0
metadata:
  hermes:
    tags: [apa, linkedin, content, psychology, writing]
    category: linkedin-post
---

# APA Kaynaklı İçerik Üretimi

APA (American Psychological Association) kaynaklarından beslenen içerik üretimi için workflow ve kurallar.

## Kullanım

Bu skill, APA makalelerinden içerik üretirken uygulanması gereken kuralları ve workflow'u tanımlar:

1. LinkedIn postları (900 karakter)
2. Blog yazıları (1500-2000 karakter)
3. Podcast script'leri (10 dakika)

## ⚠️ ZORUNLU KURALLAR

### 1. Spesifik APA Referans
"APA'nın araştırmasına göre" gibi genel ifadeler **KESİNLİKLE YASAK**. Bunun yerine:

| Yanlış | Doğru |
|--------|-------|
| "APA'nın araştırmasına göre..." | "Hertenstein ve arkadaşlarının 2019'da Sleep Medicine Reviews'da yayımladığı meta-analize göre..." |
| "Bilimsel çalışmalar gösteriyor ki..." | "Geçen yıl JAMA Psychiatry'de yayımlanan bir çalışmada..." |
| "Araştırmalar diyor ki..." | "Blom ve ekibinin 2017'de Sleep dergisinde gösterdiği gibi..." |

**Format:** Yazar(lar) ve ark., Yıl, Dergi Adı

### 2. Makalenin Tamamından Beslen
Sadece giriş bölümüne takılıp kalma. Makalenin TÜM bölümlerinden beslen:
- Giriş / Arka plan
- Mekanizmalar (stres-uyku döngüsü, ödül sistemi, duygusal reaktivite)
- İstatistikler ve veriler
- Tedavi yöntemleri
- Klinisyen çıkarımları
- Özel popülasyonlar

### 3. Rakam ve İstatistik Kullan
Makalede geçen somut rakamları kullan:
- "Tek bir uykusuz gece bile sistemik inflamasyonu tetikliyor"
- "%73'ü depresif belirtiler gösteriyordu, CPAP sonrası sadece %4"
- "100'den fazla randomize kontrollü çalışma"

### 4. İnfographic Görsel
Post altında verileri özetleyen bir tablo/infographic olsun.

**Script:** `~/.hermes/scripts/linkedin_infographic.py`

**Kullanım:**
```bash
python3 ~/.hermes/scripts/linkedin_infographic.py '[{"number": "%73", "label": "Sleep apne hastas\u0131 depresif", "sub": "Tedavi edilmemi\u015f 293 ki\u015finin %73\u2019\u00fc depresif", "source": "Edwards ve ark., 2015"}]'
```

**JSON formatı:**
```json
[
  {
    "number": "büyük rakam/yüzde",
    "label": "kısa başlık (2-4 kelime)",
    "sub": "tek cümle açıklama",
    "source": "yazar ve yıl"
  }
]
```

Maks 6 veri noktası. Çıktı: `MEDIA:/tmp/gorsel.jpg`

## LinkedIn Post Formatı

- Dil: **Türkçe**
- Uzunluk: **600-900 karakter**
- Ton: Konuşma dili ("Bak", "düşünsene", "aslında", "ilginç olan şu ki")
- Hitap: **"sen"** (asla "siz")
- KISA paragraflar (maks 2-3 cümle)
- Maddeler halinde DEĞİL, akıcı metin

### YASAKLAR
- ❌ Emoji
- ❌ #terapi veya "terapi" kelimesi
- ❌ CTA/soru ("ne düşünüyorsun?", "yorumlarda buluşalım")
- ❌ Genel referans ("APA'nın araştırmasına göre")

## Workflow (Cron Job İçin)

1. **KAYNAĞI OKU** — `~/wiki/apa-articles/` altındaki en güncel .md dosyasını oku
2. **POSTU YAZ** — 600-900 karakter, spesifik referanslı, tüm makaleden beslenmiş
3. **KONTROL ET** — karakter sayısı, yasaklı kelimeler, referans kontrolü
4. **İNFOGRAPHIC HAZIRLA** — posttaki veri noktalarından JSON dizi oluştur
5. **GÖRSEL OLUŞTUR** — `linkedin_infographic.py` çalıştır
6. **ÇIKTI VER** — post metni + MEDIA: görsel yolu

## Cron Job Prompt Şablonu

Model: `gpt-5.4-mini` / `custom:Pollinations`
enabled_toolsets: `["terminal", "web", "file", "search", "delegation"]`
