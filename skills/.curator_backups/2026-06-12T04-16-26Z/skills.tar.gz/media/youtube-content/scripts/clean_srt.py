#!/usr/bin/env python3
"""Clean YouTube auto-caption SRT from overlapping segments.

YouTube auto-captions produce 3 overlapping blocks per segment.
This script extracts only the first (complete) text block.

Usage: python3 clean_srt.py <input.srt> [output.txt]
"""
import re
import sys

if len(sys.argv) < 2:
    print(f"Usage: {sys.argv[0]} <input.srt> [output.txt]")
    sys.exit(1)

with open(sys.argv[1]) as f:
    text = f.read()

# Split on double newlines
blocks = re.split(r'\n\n+', text.strip())
clean = []

for block in blocks:
    if not block.strip():
        continue
    lines = block.strip().split('\n')
    # Skip segment number and timestamp lines, keep text
    text_lines = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line[0].isdigit() or '-->' in line:
            continue
        text_lines.append(line)
    
    if text_lines:
        clean.append(' '.join(text_lines))

output = ' '.join(clean)

if len(sys.argv) > 2:
    with open(sys.argv[2], 'w') as f:
        f.write(output)
    print(f"Written {len(output)} chars to {sys.argv[2]}")
else:
    print(output[:500] + f"... ({len(output)} chars total)")
