# Pollinations Whisper API — Yetenek ve Limitler

**Endpoint:** `POST https://gen.pollinations.ai/v1/audio/transcriptions`
**Model:** `whisper`
**Auth:** `Authorization: Bearer $POLLINATIONS_API_KEY`

## Çalışan Özellikler

| Parametre | Değer | Not |
|-----------|-------|-----|
| `model` | `whisper` | Tek model |
| `language` | `tr` | Türkçe çok iyi (prob: 1.00) |
| `response_format` | `json` (varsayılan) | `text` + `duration` + `language` |
| `response_format` | `verbose_json` | `text` + `words[]` (word-level timestamps) + `usage` |
| `task` | `transcribe` (varsayılan) | Çalışıyor |

## Çalışmayan Özellikler

| Parametre | Hata | Detay |
|-----------|------|-------|
| `response_format=srt` | 501 not_implemented | Upstream OVH desteklemiyor |
| `task=translate` | Sessizce başarısız | Parametre kabul ediliyor ama çeviri yapmıyor, orijinal dilde dönüyor |
| `temperature` | Yok | OpenAI parametresi, Pollinations'da etkisiz |

## Dosya Boyutu Limiti

- **56MB (60dk mp3 @128kbps):** 524 timeout → BAŞARISIZ
- **9.2MB (10dk mp3 @128kbps):** ~32sn → GÜVENLİ
- **Tahmini limit:** ~10-15MB arası bir yerde
- **Strateji:** 10'ar dakikalık parçalara böl (`ffmpeg -f segment -segment_time 600`)

## Performans (10dk parça)

```
Süre: ~32 saniye
Ses: 600 saniye
Ratio: 0.05x realtime (sesin ~19 katı hızlı)
Transkript: ~7.300 karakter, ~1.000 kelime
Dil tespiti: tr, 1.00 güven
```

## verbose_json Çıktı Yapısı

```json
{
  "task": "transcribe",
  "success": true,
  "language": "tr",
  "duration": 599.977,
  "text": "tam metin...",
  "words": [
    {"word": "Tibet", "start": 4.96, "end": 5.96},
    {"word": "'in", "start": 5.96, "end": 6.18}
  ],
  "segments": [],
  "diarization": null,
  "usage": {...}
}
```

- `segments` her zaman boş — cümle bazlı segment yok
- `words` her kelime için start/end zamanı verir
- `diarization` destekleniyor ama kullanılmadı

## Karşılaştırma: Yerel vs Pollinations

| | Yerel faster-whisper small | Pollinations whisper |
|---|---|---|
| 60dk video | ~66 dakika | ~3.2 dakika (7 parça) |
| Hız | 1.1x realtime | 0.05x realtime |
| RAM | 360MB | 0 |
| Word timestamp | Yok | Var (verbose_json) |
| SRT çıktı | Yok | Yok |
| Translate | Yok | Yok |
| Maliyet | Ücretsiz | Pollinations abonelik |
| Dosya limiti | Yok (streaming) | ~10MB/parça |
