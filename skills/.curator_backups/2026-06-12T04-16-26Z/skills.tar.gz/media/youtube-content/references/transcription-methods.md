# Transkripsiyon Yöntemleri Karşılaştırması

27 Mayıs 2026 — Oracle ARM64, 1 CPU, 5.8GB RAM

## Test Videoları
- Beyhan Budak — "Neden Kötü İnsanlar Daha Zengin ve Başarılı?" (20dk)
- Damla Donmez — "TİBET'İN ÖLÜLER KİTABI" (60dk)

## Karşılaştırma

| Yöntem | 20dk video | 60dk video | RAM | Doğruluk |
|--------|-----------|-----------|-----|----------|
| YouTube auto-caption + WARP | ~3sn | ~3sn | 0 | İyi (bazen bozuk) |
| Pollinations whisper | ~32sn | ~3dk | 0 | Çok iyi ✅ |
| Yerel faster-whisper small | ~22dk | ~66dk | 360MB | Çok iyi ✅ |

## Pollinations Whisper Detay

- Endpoint: `POST https://gen.pollinations.ai/v1/audio/transcriptions`
- Model: `whisper`
- Auth: Bearer token (POLLINATIONS_API_KEY)
- Format: multipart/form-data
- Parametreler: `model=whisper`, `language=tr`, `file=@audio.mp3`
- Cevap: `{"task": "transcribe", "success": true, "language": "tr", "duration": 599.977, "text": "..."}`

### Gerçek Benchmark (27 May 2026)
- 10dk MP3 (128kbps, 9.2MB): **32 saniye**
- 60dk MP3 (128kbps, 56MB): 524 timeout — çok büyük!

### Dosya Boyutu Limiti
- **Güvenli:** ~10MB (10dk @ 128kbps)
- **Timeout:** 56MB+ → 524 hata
- **Çözüm:** `ffmpeg -f segment -segment_time 600` ile 10'ar dakikalık parçalara böl
- 60dk video = 6 parça × 32sn = ~3dk toplam

## Yerel Whisper Small Detay

- Kütüphane: faster-whisper 1.2.1
- Model: Systran/faster-whisper-small (464MB disk)
- Load time: 1.8s (cached), 9.6s (cold)
- RAM: ~360MB total (model + runtime)
- Compute: CPU, int8 quantization
- Hız: 1.1x realtime (1sn ses = 1.1sn işlem)
- Türkçe: language detection prob 1.00

## SRT Overlapping Sorunu

YouTube auto-caption SRT çıktısı her segment için 3 overlapping blok içerir:
1. Tam metin (örn. "Merhaba sevgili dostum. Öyle bir zaman diliminde yaşıyoruz ki")
2. İlk yarı + satır sonu (örn. "Merhaba sevgili dostum. Öyle bir zaman\\r\\n")
3. İkinci yarı (örn. "diliminde yaşıyoruz ki iyi bir insan\\r\\n")

Temiz transkript için sadece ilk tam metin bloğunu al.
