---
name: youtube-content
description: "YouTube içeriğini işle: transkript çek → notebooklm'e ekle → wiki'ye kaydet → değerlendir → uygulama fikri yürüt. ASLA özet çıkarma."
platforms: [linux, macos, windows]
---

# YouTube Content Tool

## When to use

Use when the user shares a YouTube URL or video link. Extract transcript → save key info to wiki → evaluate the content → think about practical application. **NOT for summarization** — Edel's workflow is: bilgiyi çıkar, kaydet, değerlendir, uygulama fikri yürüt.

Also useful for: requesting a transcript, extracting chapters/quotes, or reformatting content for analysis.

**3 katmanlı transkripsiyon stratejisi (Edel onaylı):**
1. YouTube auto-caption (WARP ile) — her zaman önce dene
2. Pollinations whisper API — auto-caption overlapping/yoksa ana yol
3. Yerel faster-whisper small — Pollinations down ise son çare

⚠️ **SRT overlapping tuzağı:** YouTube auto-caption'ları SRT formatında her cümleyi 3 kere tekrarlar (overlapping segments). `clean_srt.py` sadece zaman damgalarını temizler, 3x tekrarı gidermez. Çıktıda aynı cümleler 3'er 3'er tekrarlanıyorsa SRT'yi düzeltmeye çalışma — hemen Method 2'ye geç.

Detaylı karşılaştırma: `references/transcription-methods.md`
SRT temizleme: `python3 SKILL_DIR/scripts/clean_srt.py input.srt output.txt`

## Setup

```bash
pip install youtube-transcript-api
uv pip install PySocks  # SOCKS5 proxy desteği (cloud IP'ler için)
```

## Transcript Extraction Methods (KATI tercih sırası — bunu değiştirme!)

### Method 1: yt-dlp auto-captions (HER ZAMAN ÖNCE BUNU DENE)

YouTube'un otomatik altyazılarını doğrudan indirir. Saniyeler içinde tamamlanır. Cloud IP'ler için WARP proxy gerekir.

```bash
# Metadata kontrol (auto-caption var mı?)
yt-dlp --proxy socks5://127.0.0.1:1080 --dump-json "URL" -o /dev/null > /tmp/v.json 2>/dev/null \
  && python3 -c "import json; d=json.load(open('/tmp/v.json')); print(f'title: {d[\"title\"]}\nduration: {d[\"duration\"]}s'); ac=d.get('automatic_captions',{}); print(f'auto-captions: {list(ac.keys()) if ac else \"YOK\"}')"

# Türkçe auto-caption'ları SRT formatında indir (video indirilmez)
yt-dlp --proxy socks5://127.0.0.1:1080 \
  --write-auto-subs --sub-lang tr --skip-download --convert-subs srt \
  "URL" -o "/tmp/transcript_%(id)s"
```

**ÖNEMLİ:** yt-dlp JSON çıktısı pipe ile Python'a aktarılamaz (stderr karışır). Dosyaya yazıp sonra oku. `-o /dev/null > file 2>/dev/null` kalıbını kullan.

### Method 2: Pollinations Whisper (auto-caption YOKSA veya BOZUKSA — ana yol)

Cloud tabanlı, hızlı. 60dk video ~2-3dk. Türkçe doğruluk çok iyi.

```bash
# 1. Sesi indir (format 140 = medium m4a)
yt-dlp --proxy socks5://127.0.0.1:1080 -f 140 "URL" -o "/tmp/yt_audio.%(ext)s"

# 2. 16kHz mono wav'a çevir
ffmpeg -y -i /tmp/yt_audio.m4a -ar 16000 -ac 1 /tmp/yt_audio.wav

# 3. Pollinations whisper API (model=whisper, language=tr)
curl -s -X POST "https://gen.pollinations.ai/v1/audio/transcriptions" \
  -H "Authorization: Bearer $POLLINATIONS_API_KEY" \
  -F "model=whisper" \
  -F "language=tr" \
  -F "file=@/tmp/yt_audio.wav"
```

Pollinations whisper endpoint: `POST /v1/audio/transcriptions`, model=`whisper`, multipart form (file + model + language).

**KRİTİK — Dosya boyutu limiti:** 56MB üzeri 524 timeout verir. **20MB'a kadar tek seferde güvenli** (09 Haz 2026 test: 19MB WAV, ~12dk ses, Pollinations Whisper çalıştı, tam transkript döndü). 20MB+ için `ffmpeg -f segment -segment_time 600 -ar 16000 -ac 1` ile parçalara böl, her birini ayrı gönder, sonuçları birleştir.

Performans: 10dk parça ~32sn işlem, ~7300 karakter. 12dk parça (19MB) ~5sn işlem.

Detaylı benchmark ve karşılaştırma: `references/transcription-methods.md`
Pollinations whisper API detayları (limitler, yetenekler): `references/pollinations-whisper-api.md`

### Method 3: Yerel faster-whisper small (SON ÇARE — Pollinations down ise)

Sadece Pollinations ulaşılamaz olduğunda veya çok küçük işler için. 1 CPU ARM64'te yavaş.

```bash
python3 -c "
from faster_whisper import WhisperModel
model = WhisperModel('small', device='cpu', compute_type='int8')
segments, _ = model.transcribe('/tmp/yt_audio.wav', language='tr', beam_size=5)
print(' '.join(s.text for s in segments))
"
```

**Performans (1 CPU ARM64):** ~1.1x realtime, 360MB RAM. 60dk video ~66dk işlem. SADECE Pollinations down ise kullan.

## Output Formats

After fetching the transcript, format it based on what the user asks for. **NOTE:** Edel için varsayılan akış output formatı kullanmaz — bilgiyi wiki'ye kaydet + değerlendir. Output formatları sadece Edel açıkça "bunu şu formata çevir" derse kullan.

- **Chapters**: Group by topic shifts, output timestamped chapter list
- **Summary**: Concise 5-10 sentence overview of the entire video
- **Chapter summaries**: Chapters with a short paragraph summary for each
- **Thread**: Twitter/X thread format — numbered posts, each under 280 chars
- **Blog post**: Full article with title, sections, and key takeaways
- **Quotes**: Notable quotes with timestamps

### Example — Chapters Output

```
00:00 Introduction — host opens with the problem statement
03:45 Background — prior work and why existing solutions fall short
12:20 Core method — walkthrough of the proposed approach
24:10 Results — benchmark comparisons and key takeaways
31:55 Q&A — audience questions on scalability and next steps
```

## Workflow (Edel için — özet çıkarma, işle ve kaydet)

1. **ÖNCE auto-caption dene (Method 1):** yt-dlp ile `--write-auto-subs --sub-lang tr`. Saniyeler içinde.
2. **Auto-caption YOKSA veya overlapping SORUNLUYSA → Pollinations whisper (Method 2):** Sesi indir (format 140), 16kHz mono wav'a çevir, Pollinations API'ye gönder. Dakikalar içinde.
3. **Pollinations DOWN ise → yerel whisper (Method 3):** Son çare. 1.1x realtime, yavaş ama her zaman çalışır.
4. **Cloud IP'deysen:** tüm yt-dlp çağrılarında `--proxy socks5://127.0.0.1:1080` kullan.
5. **Validate:** çıktı boş değil mi, doğru dil mi kontrol et. Auto-caption SRT'sinde 3x overlapping varsa (aynı cümle 3 kere tekrar ediyorsa) → Method 2'ye geç.
6. **Chunk if needed:** transkript ~50K karakteri aşarsa parçala (~40K + 2K overlap).
7. **ÇİFT KAYIT (Edel onaylı — 09 Haz 2026):**
   - **A — NotebookLM:** YouTube URL'sini NotebookLM'e URL source olarak ekle (`mcp_notebooklm_mcp_source_add` ile `type="url"`). NotebookLM kendi transcript'ini çeker ve podcast/quiz/study guide üretmek için hazır olur. **Hangi notebook (09 Haz 2026):**
     - AI/tool/coding içerikleri → `🛠️ Tech Tools Updates` (id: e263e756)
     - Hermes Agent ile ilgili → `Hermes Docs` (id: 194c049a)
     - Psikoloji/akademik → `APA Bilgi` (id: c44469fe)
     - Diğer → en uygun notebook'u seç veya yenisini oluştur
   - **B — Wiki:** Temiz transkripti `~/wiki/concepts/` veya uygun klasöre kaydet. Detaylar, benchmark verileri, önemli alıntılar dahil olsun.
   - **Neden ikisi birden:** NotebookLM (A) podcast/quiz için, Wiki (B) kalıcı bilgi tabanı için. İkisi farklı amaçlara hizmet eder, birbirini tamamlar.
8. **Değerlendir:** Edel ile içeriği konuş — ne anladın, nereleri ilginç buldun, hangi kısımlar tartışmaya değer.
9. **Uygulama fikri yürüt:** Bu bilgi bizim için ne ifade ediyor? Nasıl kullanabiliriz? Denemeye değer mi?
10. **ÖZET ÇIKARMA.** Bilgiyi işle, kaydet, değerlendir. Bilgi zaten videonun kendisinde var.

## Error Handling

### Known Failure Modes (Sıralı kontrol et)

**1. IP blocked (TCP/HTTP 403)**
- **Belirti:** yt-dlp timeout, curl connection refused, HTTP 403
- **Neden:** Oracle/AWS/GCP IP aralıkları YouTube tarafından bloklanır
- **Çözüm:** WARP SOCKS5 proxy (`--proxy socks5://127.0.0.1:1080`). Load `warp-proxy` skill for setup.

**2. PO Token / Bot Detection (SESSİZ BAŞARISIZLIK)** ⚠️
- **Belirti:** yt-dlp auto-caption indirir, SRT dosyası oluşur AMA içi boştur veya yalnızca 1 satır `WEBVTT` header'ı vardır. WARP bağlıdır (timeout/403 yok), video bilgisi gelir, transcript boş döner.
- **Neden:** Google / YouTube, Cloudflare WARP IP aralıklarını (104.28.x.x) bot trafiği olarak sınıflandırır. YouTube'un innertube API'si PO (Proof of Origin) token kontrolü yapar — token yoksa transcript boş/hatalı döner, ama TCP bağlantısı ve video meta verileri normal görünür. Bu "sessiz başarısızlık"tır — hata mesajı yok, sadece boş çıktı vardır.
- **Ayırt etme:** `ls -la /tmp/transcript_*.srt` yap, dosya boyutuna bak. 0-100 byte ise → PO token tuzağı. yt-dlp JSON'da `automatic_captions` anahtarı dolu ama içerik boş.
- **Çözüm 1 (Hemen):** Method 2'ye (Pollinations Whisper) geç. Ses indir → transkripte et. PO token bypass gerekmez — Whisper doğrudan sesten okur.
- **Çözüm 2 (Kesin):** Playwright CDP ile headless Chrome'dan YouTube sayfasını aç. captureStream veya CDP üzerinden transcript DOM'unu parse et. Gerçek browser Google'a gerçek kullanıcı gibi görünür, PO token gerektirmez.
- **Çözüm 3 (İleri düzey):** yt-dlp + browser'dan export edilmiş cookies.txt + PO token injection. Ama PO token'ın TTL'si kısadır, sürekli refresh gerekir. Sadece otomatize cron job için uğraşmaya değer.
- **ÖNEMLİ:** PO token sorunu yaşarken SRT'yi düzeltmeye çalışma, video formatını değiştirme, proxy rotasyonu dene — hepsi zaman kaybı. Kök neden PO token'dır, IP veya format değil. Doğrudan Method 2 veya Playwright'a geç.

**3. Auto-caption yok veya overlapping bozuk**
- **Belirti:** yt-dlp `--write-auto-subs` başarılı ama SRT içinde her cümle 3 kere tekrarlanıyor
- **Neden:** YouTube'un overlapping segment formatı
- **Çözüm:** Hemen Method 2'ye (Pollinations whisper) geç. SRT'yi düzeltmeye çalışma.
- **Ayırt etme:** Çıktıda aynı cümleler 3'er 3'er tekrarlanıyorsa → overlapping. clean_srt.py sadece zaman damgasını temizler, 3x dedup YAPMAZ.

**4. Pollinations whisper down**
- **Belirti:** Pollinations API 500/503/timeout
- **Çözüm:** Method 3'e geç (yerel faster-whisper small). Yavaş (~1.1x realtime) ama her zaman çalışır.
- **Private/unavailable video**: hatayı ilet, kullanıcıdan URL'yi kontrol etmesini iste.
- **yt-dlp JSON pipe fails silently**: `-o /dev/null > file 2>/dev/null` kalıbını kullan, pipe etme.
- **SRT overlapping segments (3x):** YouTube auto-caption her segment için 3 overlapping blok üretir. clean_srt.py sadece zaman damgalarını temizler, 3x tekrarlanan içeriği DEDUP ETMEZ. Sonuç: her cümle 3 kere tekrar eder. **Tespit:** çıktıda aynı cümleler 3'er 3'er tekrarlanıyorsa → auto-caption bozuk demektir. **Çözüm:** SRT'yi düzeltmeye çalışma, hemen Method 2'ye (Pollinations Whisper) geç. Pollinations her zaman temiz, tekrarsız çıktı verir.
