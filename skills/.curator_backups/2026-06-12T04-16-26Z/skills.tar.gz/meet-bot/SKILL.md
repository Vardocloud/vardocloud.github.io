---
name: meet-bot
description: "Google Meet toplantılarına otomatik katılım ve transkripsiyon. meeting-bot skill'ini absorbe etti."
version: 1.2.0
metadata:
  hermes:
    category: meet-bot
---

# Meet-Bot Skill

Google Meet toplantilarina otomatik katilim ve transkripsiyon.

## Aktif Cozum: Hermes google_meet Plugin

Artik **Hermes'in resmi `google_meet` plugin'i** kullaniliyor (v0.2.0).
Plugin Google Meet'in kendi altyazilarini DOM'dan okuyarak transkripsiyon yapar.
Ses kaydi veya Whisper gerekmez.

### Komutlar

```bash
# Manuel join (CLI):
hermes meet join "https://meet.google.com/abc-defg-hij" --guest-name Sudenaz

# Tam otomasyon (seminar.sh):
bash /home/ubuntu/meet-bot/seminar.sh "https://meet.google.com/abc-defg-hij" Sudenaz

# Durum kontrolu:
hermes meet status

# Transkript goruntuleme:
hermes meet transcript

# Toplantidan ayril:
hermes meet stop
```

### Vanitas icin Dogal Dil Triggerlari

- "meeting basladi"
- "toplanti basladi"
- "gir <URL>"
- "katil <URL>"
- "seminer"
- Herhangi bir meet.google.com URL'i

### Kurulum

```bash
hermes plugins enable google_meet
hermes meet install
hermes meet setup
```

## Google Cloud IP Engellemesi (Evrensel)

**Google, veri merkezi IP'lerinden TÜM hizmetlerine otomatik erişimi engelliyor.** Bu sadece Meet değil, YouTube, YouTube Transcript API, yt-dlp dahil her şey için geçerli.

| Hizmet | Engel | Hata |
|--------|-------|------|
| Google Meet | Giriş + join | `Couldn't sign you in` |
| YouTube (yt-dlp) | Video/audio indirme | `Sign in to confirm you're not a bot` |
| YouTube Transcript API | Altyazı çekme | `IP blocked` |
| YouTube-to-MP3 servisleri | Dolaylı indirme | HTML sayfası, boş dosya |

**Tek çözüm:** Edel'in kendi cihazından cookie export. Detay: `references/cookie-export-auth.md` ve `references/google-cloud-ip-block.md`

### faster-whisper STT Test Sonuçları (27 May 2026)

Small model Türkçe'de başarılı:
- Dil algılama: %100 güven (tr)
- Yükleme: ~19s (CPU, int8)
- Transkripsiyon: ~17s (5.5s ses)
- Kalite: Noktalama ve küçük yazım farkları dışında birebir

Gerçek YouTube sesiyle test yapılamadı (Google IP engeli). Ses dosyası gelince test tekrarlanmalı.

**Alternatif: WARP+ SOCKS5 Proxy** — Google Cloud IP engelini tamamen aşar. Cookie export'a gerek kalmadan Meet'e giriş yapabilir. Detay: `../devops/warp-proxy/SKILL.md` skill'i. WARP+ üzerinden gelen trafik Google tarafından engellenmez.

**Auth üç yöntemle yapılır (zorluk sırasına göre):**

### 1. Cookie Export (EN KOLAY, EN GÜVENİLİR) ⭐
Google Cloud IP'lerinden otomatik tarayıcıyla giriş **imkansız** — stealth, CDP, Chrome profili dahil tüm yöntemler `"Couldn't sign you in"` hatası alır.

**Çözüm A:** Edel'in kendi cihazından cookie export. Detay: `references/cookie-export-auth.md`

**Çözüm B:** Cloudflare WARP+ WireGuard tüneli ile sunucu IP'sini maskeleme. Detay: `../devops/warp-proxy/SKILL.md`

### 2. VNC + Manuel Giriş (zor, mobilde çalışmaz)
Headless sunucuda Xvfb + x11vnc/noVNC kurulumu gerekir. noVNC mobil tarayıcıda çalışmaz, sadece masaüstü VNC client ile. Detay: `references/auth-troubleshooting.md` → "Headless Workaround"

### 3. Masaüstü Sunucu (headed, en basit)
`hermes meet auth` — tarayıcı açılır, Google'a giriş yap, Enter'a bas.

**Auth doğrulama:** Kaydedilen auth.json'da en az 5 Google cookie olmalı. `<5 → auth başarısız, tekrar dene.

**Auth neden önemli:** Guest modda bot "Ask to join" yapar ve lobide host'un kabul etmesini bekler. Host bilinmeyen ismi reddedebilir. **Auth yapılmış Google hesabıyla lobi atlanabilir, doğrudan girer.**

Auth basarili mi kontrol: `python3 -c "import json; d=json.load(open('$HOME/.hermes/workspace/meetings/auth.json')); print(len(d.get('cookies',[])), 'cookies')"` → 5+ Google cookie'si varsa basarili.

### Mimari

```
Hermes Agent -> google_meet plugin -> Playwright Chromium (headless)
  -> meet.google.com -> caption DOM scraping -> transcript.txt
  -> AI agent post-processing (ozet, aksiyon maddeleri)
```

### Transkript Konumu

`~/.hermes/workspace/meetings/<meeting-id>/transcript.txt`

### Yedek Cozum

Plugin calismazsa manuel bot: `/home/ubuntu/meet-bot/bot-v5.js` (CDP tabanli)

### Pitfalls

| Hata | Anlami | Cozum |
|------|--------|-------|
| `host denied admission` | Host manuel olarak reddetti. Bot "Ask to join" tiklar, lobide gorunur, host "Deny" der. **CLI'da hemen cikar, meet_join() aracinda canli kalir.** | Host'a haber ver. Alternatif: auth yapip lobiyi atla. **Her zaman meet_join() aracini kullan.** Detay: `references/auth-troubleshooting.md` |
| `lobby timeout` | Host 5 dakika icinde ne kabul ne red etti. | Host'un toplantida oldugundan emin ol, tekrar dene. |
| `meeting not found` | Link gecersiz veya toplanti baslamadi. | Linki kontrol et. |
| `Missing X server` | `hermes meet auth` headless sunucuda X olmadigi icin patlar. | Xvfb + x11vnc workaround'u: `references/auth-troubleshooting.md` |
| **auth.json confusion** | `~/.hermes/auth.json` (credential pool, API keys) ile `~/.hermes/workspace/meetings/auth.json` (Playwright storage state) ayni isim ama tamamen farkli dosyalar. Edel "auth yapildi" dediginde credential pool'u kastediyor olabilir. | Meet plugin'in kullandigi: `workspace/meetings/auth.json`. 5+ Google cookie'si varsa gecerli. Detay: `references/auth-troubleshooting.md` |
| **Auth silently failed** | `setup-auth-v3.js` "Login complete" dese bile Google handshake tamamlanmamis olabilir — browser kapanmadan once cookie'ler kaydedilmez. | Auth sonrasi MUTLAKA dogrula: `myaccount.google.com`'a git, "Sign in" yaziyorsa auth gecersiz. |
| **Couldn't sign you in** | Google Cloud IP'sinden otomatik tarayıcı algılandı. `"This browser or app may not be secure"`. **Stealth, CDP, Chrome profili — hiçbiri çalışmaz.** | **Cookie export** tek çözüm: `references/cookie-export-auth.md` |

Teshis: `hermes meet status` → `error:"host denied admission"` + `leaveReason:"denied"`. `status.json`'da `joinAttemptedAt` dolu ama `joinedAt` null → bot lobiden oteye gecememis.

## Natural Language Triggers (AUTO-LOAD)

## NotebookLM Arşiv Fallback
notebook: `6c7f3daa-1640-4fad-9917-ec44bc432e58` | label: "Yapay Zeka Araçları"

Bilgi eksikse: `cross_notebook_query("Meet bot cookie ayarları", notebook_names="6c7f3daa")`

When Edel mentions ANY of these, the meet-bot skill MUST be loaded:
- "meeting basladi"
- "toplanti basladi"
- "gir" + URL
- "katil" + URL
- "seminer"
- Any meet.google.com URL in the message

## CRITICAL: Use Hermes Plugin

ALWAYS use the **tool** (not CLI) — CLI sometimes exits early with "host denied" while the tool stays alive:

1. **Tool (tercih):** `meet_join(url="...", guest_name="Sudenaz", mode="transcribe")` — Vanitas'in built-in meet_join araci. Bot canli kalir, toplanti sonuna kadar bekler.
2. **CLI (yedek):** `hermes meet join '<URL>' --guest-name Sudenaz` — bazen hemen denied verebiliyor.
3. **Bash:** `bash /home/ubuntu/meet-bot/seminar.sh '<URL>' Sudenaz`

NEVER use browser-click, browser-type, browser-navigate tools for Google Meet join.
The official google_meet plugin handles everything.
