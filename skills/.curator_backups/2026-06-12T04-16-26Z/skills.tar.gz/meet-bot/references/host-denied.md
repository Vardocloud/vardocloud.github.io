# Host Denied Admission — Diagnostic Guide

## Symptom

```bash
hermes meet status
# {
#   "ok": true,
#   "alive": false,
#   "inCall": false,
#   "error": "host denied admission",
#   "leaveReason": "denied",
#   "joinAttemptedAt": <timestamp>,
#   "joinedAt": null,
#   "lobbyWaiting": false
# }
```

## What Happened

1. Bot navigated to meet.google.com URL ✅
2. Bot clicked "Ask to join" button ✅
3. Bot appeared in lobby as guest name (e.g., "Sudenaz") ✅
4. Host saw the join request and clicked **Deny** ❌
5. Bot detected "You can't join this video call" text on page → set `error: "host denied admission"`

## Detection Code (meet_bot.py:777-793)

The `_detect_denied()` function checks for these English strings in page body:
- `You can't join this video call`
- `You were removed from the meeting`
- `No one responded to your request to join`

## Root Cause

The meeting has "host must admit" enabled (Google Meet default for non-org guests).
The host sees an unknown name and manually denies.

## Fix

**Bot-side: NOTHING can be done.** The denial comes from the host's manual action.

**External fixes:**
1. Message the host: "Asistanim Sudenaz toplantiya katilacak, kabul eder misin?"
2. Host changes meeting settings to allow direct join (no lobby)
3. Use a meeting link where the bot's Google account is in the same org (auto-admit)

## Diagnostics Commands

```bash
# Full status
hermes meet status

# Raw status.json
cat ~/.hermes/workspace/meetings/<meeting-id>/status.json

# Bot log (usually minimal)
cat ~/.hermes/workspace/meetings/<meeting-id>/bot.log
```

## Known Instance

2026-05-25: kaf-qrzs-vjz — Two attempts, both denied. Name "Sudenaz", host unknown.
